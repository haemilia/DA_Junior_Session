```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import missingno as msno
import datetime
```

Kaggle에서 가져온 데이터셋: https://www.kaggle.com/datasets/gianinamariapetrascu/top-100-k-drama-2023 


```python
df = pd.read_csv("C:/Users/lhi30/Haein/2023/YBIGTA/DA/Junior_Session/Assignments/HW3/top100_kdrama.CSV")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Tags</th>
      <th>Synopsis</th>
      <th>Rank</th>
      <th>Popularity</th>
      <th>Score</th>
      <th>Episodes</th>
      <th>Duration</th>
      <th>Watchers</th>
      <th>Start_date</th>
      <th>End_date</th>
      <th>Day_aired</th>
      <th>Main Role</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Move to Heaven</td>
      <td>Life, Drama</td>
      <td>Uncle-Nephew Relationship, Autism, Death, Sava...</td>
      <td>Han Geu Roo is a 20-year-old with Autism. He w...</td>
      <td>8</td>
      <td>94</td>
      <td>9.2</td>
      <td>10</td>
      <td>52</td>
      <td>64,103</td>
      <td>5/14/2021</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Lee Je Hoon, Tang Jun Sang, Hong Seung Hee</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Weak Hero Class 1</td>
      <td>Action, Youth, Drama</td>
      <td>Smart Male Lead, Bromance, School Bullying, Vi...</td>
      <td>Yeon Shi Eun is a model student who ranks at t...</td>
      <td>12</td>
      <td>290</td>
      <td>9.1</td>
      <td>8</td>
      <td>40</td>
      <td>32,415</td>
      <td>11/18/2022</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Park Ji Hoon, Hong Kyung, Choi Hyun Wook, Kim ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Hospital Playlist Season 2</td>
      <td>Romance, Life, Drama, Medical</td>
      <td>Multiple Mains, Band, Music, Strong Female Lea...</td>
      <td>Everyday is extraordinary for five doctors and...</td>
      <td>14</td>
      <td>177</td>
      <td>9.1</td>
      <td>12</td>
      <td>100</td>
      <td>43,574</td>
      <td>6/17/2021</td>
      <td>9/16/2021</td>
      <td>Thursday</td>
      <td>Jo Jung Suk, Jung Kyung Ho, Jeon Mi Do, Yoo Ye...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Flower of Evil</td>
      <td>Thriller, Romance, Crime, Melodrama</td>
      <td>Deception, Family Secret, Mystery, Suspense, S...</td>
      <td>Although Baek Hee Sung is hiding a dark secret...</td>
      <td>16</td>
      <td>31</td>
      <td>9.1</td>
      <td>16</td>
      <td>70</td>
      <td>94,811</td>
      <td>7/29/2020</td>
      <td>9/23/2020</td>
      <td>Wednesday, Thursday</td>
      <td>Lee Joon Gi, Jang Hee Jin, Moon Chae Won, Seo ...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Hospital Playlist</td>
      <td>Romance, Life, Drama, Medical</td>
      <td>Nice Male Lead, Multiple Mains, Slow Romance, ...</td>
      <td>The stories of people going through their days...</td>
      <td>17</td>
      <td>51</td>
      <td>9.1</td>
      <td>12</td>
      <td>90</td>
      <td>81,568</td>
      <td>3/12/2020</td>
      <td>5/28/2020</td>
      <td>Thursday</td>
      <td>Jo Jung Suk, Jung Kyung Ho, Jeon Mi Do, Yoo Ye...</td>
    </tr>
  </tbody>
</table>
</div>



Check for missing values.


```python
df.isnull().sum()
```




    ID             0
    Title          0
    Genre          0
    Tags           0
    Synopsis       0
    Rank           0
    Popularity     0
    Score          0
    Episodes       0
    Duration       0
    Watchers       0
    Start_date     0
    End_date      12
    Day_aired      0
    Main Role      0
    dtype: int64



'End_date'에 12개의 null 데이터가 있다. 그 데이터는 어떤 특징을 가지고 있는 지 보자.


```python
df[df.isnull().any(axis=1)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Tags</th>
      <th>Synopsis</th>
      <th>Rank</th>
      <th>Popularity</th>
      <th>Score</th>
      <th>Episodes</th>
      <th>Duration</th>
      <th>Watchers</th>
      <th>Start_date</th>
      <th>End_date</th>
      <th>Day_aired</th>
      <th>Main Role</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Move to Heaven</td>
      <td>Life, Drama</td>
      <td>Uncle-Nephew Relationship, Autism, Death, Sava...</td>
      <td>Han Geu Roo is a 20-year-old with Autism. He w...</td>
      <td>8</td>
      <td>94</td>
      <td>9.2</td>
      <td>10</td>
      <td>52</td>
      <td>64,103</td>
      <td>5/14/2021</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Lee Je Hoon, Tang Jun Sang, Hong Seung Hee</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Weak Hero Class 1</td>
      <td>Action, Youth, Drama</td>
      <td>Smart Male Lead, Bromance, School Bullying, Vi...</td>
      <td>Yeon Shi Eun is a model student who ranks at t...</td>
      <td>12</td>
      <td>290</td>
      <td>9.1</td>
      <td>8</td>
      <td>40</td>
      <td>32,415</td>
      <td>11/18/2022</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Park Ji Hoon, Hong Kyung, Choi Hyun Wook, Kim ...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>The Glory Part 2</td>
      <td>Thriller, Drama, Melodrama</td>
      <td>Strong Female Lead, Revenge, Suspense, Brief N...</td>
      <td>Moon Dong Eun's silent fury against those stud...</td>
      <td>27</td>
      <td>573</td>
      <td>9.0</td>
      <td>8</td>
      <td>55</td>
      <td>19,698</td>
      <td>3/10/2023</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Song Hye Kyo, Im Ji Yeon, Park Sung Hoon, Lee ...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>The Glory</td>
      <td>Thriller, Drama, Melodrama</td>
      <td>Revenge, School Bullying, School Violence, Str...</td>
      <td>A high school student dreams of becoming an ar...</td>
      <td>68</td>
      <td>202</td>
      <td>8.9</td>
      <td>8</td>
      <td>50</td>
      <td>40,456</td>
      <td>12/30/2022</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Song Hye Kyo, Im Ji Yeon, Park Sung Hoon, Lee ...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>Kingdom Season 2</td>
      <td>Thriller, Historical, Horror, Supernatural</td>
      <td>Zombies, Corruption, Strong Male Lead, Gore, S...</td>
      <td>Following the events in season one, waves of t...</td>
      <td>70</td>
      <td>249</td>
      <td>8.9</td>
      <td>6</td>
      <td>45</td>
      <td>36,037</td>
      <td>3/13/2020</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Joo Ji Hoon, Kim Sung Gyu, Bae Doo Na</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>D.P.</td>
      <td>Action, Military, Drama</td>
      <td>Military Abuse, Violence, Bromance, Desertion,...</td>
      <td>Private soldier Jun Ho is a confused youth who...</td>
      <td>120</td>
      <td>207</td>
      <td>8.8</td>
      <td>6</td>
      <td>50</td>
      <td>39,966</td>
      <td>8/27/2021</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Jung Hae In, Kim Sung Kyun, Koo Kyo Hwan, Son ...</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>Kingdom</td>
      <td>Thriller, Historical, Horror, Political</td>
      <td>Joseon Dynasty, Adapted From A Webtoon, Power ...</td>
      <td>No sooner does the Joseon King succumb to smal...</td>
      <td>129</td>
      <td>113</td>
      <td>8.8</td>
      <td>6</td>
      <td>51</td>
      <td>58,560</td>
      <td>1/25/2019</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Joo Ji Hoon, Bae Doo Na, Ryu Seung Ryong, Kim ...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>58</td>
      <td>Sweet Home</td>
      <td>Action, Horror, Drama, Sci-Fi</td>
      <td>Monsters, Gore, Survival, Character Developmen...</td>
      <td>Following the death of his family in an accide...</td>
      <td>201</td>
      <td>63</td>
      <td>8.7</td>
      <td>10</td>
      <td>52</td>
      <td>75,786</td>
      <td>12/18/2020</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Song Kang, Lee Si Young, Kim Nam Hee, Park Gyu...</td>
    </tr>
    <tr>
      <th>65</th>
      <td>66</td>
      <td>My Name</td>
      <td>Action, Thriller, Mystery, Crime</td>
      <td>Blood, Revenge, Lying, Murder, Double Identity...</td>
      <td>Following her father's murder, a revenge-drive...</td>
      <td>221</td>
      <td>87</td>
      <td>8.7</td>
      <td>8</td>
      <td>50</td>
      <td>65,658</td>
      <td>10/15/2021</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Han So Hee, Ahn Bo Hyun, Park Hee Soon</td>
    </tr>
    <tr>
      <th>71</th>
      <td>72</td>
      <td>Love to Hate You</td>
      <td>Comedy, Law, Romance</td>
      <td>Badass Female Lead, Enemies To Lovers, Social ...</td>
      <td>Yeo Mi Ran is a rookie attorney at Gilmu Law F...</td>
      <td>241</td>
      <td>471</td>
      <td>8.7</td>
      <td>10</td>
      <td>52</td>
      <td>22,953</td>
      <td>2/10/2023</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Kim Ok Bin, Kim Ji Hoon, Yoo Teo, Go Won Hee</td>
    </tr>
    <tr>
      <th>91</th>
      <td>92</td>
      <td>Money Heist: Korea - Joint Economic Area - Par...</td>
      <td>Action, Thriller, Mystery, Crime</td>
      <td>Heist, Hostage Situation, Suspense, Multiple M...</td>
      <td>Thieves overtake the mint of a unified Korea. ...</td>
      <td>340</td>
      <td>1260</td>
      <td>8.6</td>
      <td>6</td>
      <td>60</td>
      <td>9,505</td>
      <td>12/9/2022</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Yoo Ji Tae, Jeon Jong Seo, Kim Ji Hoon, Lee Hy...</td>
    </tr>
    <tr>
      <th>94</th>
      <td>95</td>
      <td>Juvenile Justice</td>
      <td>Law, Drama</td>
      <td>Hardworking Female Lead, Strong Female Lead, T...</td>
      <td>Sim Eun Seok is an elite judge with a prickly ...</td>
      <td>345</td>
      <td>476</td>
      <td>8.6</td>
      <td>10</td>
      <td>62</td>
      <td>22,768</td>
      <td>2/25/2022</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>Kim Hye Soo, Lee Sung Min, Kim Mu Yeol, Lee Ju...</td>
    </tr>
  </tbody>
</table>
</div>



End_date가 없는 데이터들을 살펴보니 모두 OTT 오리지널 드라마인걸로 보인다. OTT에서 제작하는 드라마 중 많은 드라마가 모든 에피소드가 한번에 올라오는 방식으로 되어 있어서 End_date를 따로 기입하기 어려웠던 걸로 보인다. 그러므로 이 부분은 해당 행의 Start_date 값을 넣어주겠다.


```python
df.End_date = df.End_date.fillna(df.Start_date)
df[df.isnull().any(axis=1)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Tags</th>
      <th>Synopsis</th>
      <th>Rank</th>
      <th>Popularity</th>
      <th>Score</th>
      <th>Episodes</th>
      <th>Duration</th>
      <th>Watchers</th>
      <th>Start_date</th>
      <th>End_date</th>
      <th>Day_aired</th>
      <th>Main Role</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
df.dtypes
```




    ID              int64
    Title          object
    Genre          object
    Tags           object
    Synopsis       object
    Rank            int64
    Popularity      int64
    Score         float64
    Episodes        int64
    Duration        int64
    Watchers       object
    Start_date     object
    End_date       object
    Day_aired      object
    Main Role      object
    dtype: object



### Start_date & End_date





```python
df['Start_date'] = pd.to_datetime(df['Start_date'])
df['End_date']=pd.to_datetime(df['End_date'])
```


```python
df['Air_duration'] = df['End_date'] - df['Start_date']
df[['Title','Start_date', 'End_date','Air_duration']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Title</th>
      <th>Start_date</th>
      <th>End_date</th>
      <th>Air_duration</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Move to Heaven</td>
      <td>2021-05-14</td>
      <td>2021-05-14</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Weak Hero Class 1</td>
      <td>2022-11-18</td>
      <td>2022-11-18</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Hospital Playlist Season 2</td>
      <td>2021-06-17</td>
      <td>2021-09-16</td>
      <td>91 days</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Flower of Evil</td>
      <td>2020-07-29</td>
      <td>2020-09-23</td>
      <td>56 days</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Hospital Playlist</td>
      <td>2020-03-12</td>
      <td>2020-05-28</td>
      <td>77 days</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>95</th>
      <td>Big Mouth</td>
      <td>2022-07-29</td>
      <td>2022-09-17</td>
      <td>50 days</td>
    </tr>
    <tr>
      <th>96</th>
      <td>Stranger Season 2</td>
      <td>2020-08-15</td>
      <td>2020-10-04</td>
      <td>50 days</td>
    </tr>
    <tr>
      <th>97</th>
      <td>Designated Survivor: 60 Days</td>
      <td>2019-07-01</td>
      <td>2019-08-20</td>
      <td>50 days</td>
    </tr>
    <tr>
      <th>98</th>
      <td>Cruel City</td>
      <td>2013-05-27</td>
      <td>2013-07-30</td>
      <td>64 days</td>
    </tr>
    <tr>
      <th>99</th>
      <td>Little Women</td>
      <td>2022-09-03</td>
      <td>2022-10-09</td>
      <td>36 days</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 4 columns</p>
</div>




```python
df.Air_duration = pd.to_numeric(df.Air_duration.dt.days, downcast='integer')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Tags</th>
      <th>Synopsis</th>
      <th>Rank</th>
      <th>Popularity</th>
      <th>Score</th>
      <th>Episodes</th>
      <th>Duration</th>
      <th>Watchers</th>
      <th>Start_date</th>
      <th>End_date</th>
      <th>Day_aired</th>
      <th>Main Role</th>
      <th>Air_duration</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Move to Heaven</td>
      <td>Life, Drama</td>
      <td>Uncle-Nephew Relationship, Autism, Death, Sava...</td>
      <td>Han Geu Roo is a 20-year-old with Autism. He w...</td>
      <td>8</td>
      <td>94</td>
      <td>9.2</td>
      <td>10</td>
      <td>52</td>
      <td>64,103</td>
      <td>2021-05-14</td>
      <td>2021-05-14</td>
      <td>Friday</td>
      <td>Lee Je Hoon, Tang Jun Sang, Hong Seung Hee</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Weak Hero Class 1</td>
      <td>Action, Youth, Drama</td>
      <td>Smart Male Lead, Bromance, School Bullying, Vi...</td>
      <td>Yeon Shi Eun is a model student who ranks at t...</td>
      <td>12</td>
      <td>290</td>
      <td>9.1</td>
      <td>8</td>
      <td>40</td>
      <td>32,415</td>
      <td>2022-11-18</td>
      <td>2022-11-18</td>
      <td>Friday</td>
      <td>Park Ji Hoon, Hong Kyung, Choi Hyun Wook, Kim ...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Hospital Playlist Season 2</td>
      <td>Romance, Life, Drama, Medical</td>
      <td>Multiple Mains, Band, Music, Strong Female Lea...</td>
      <td>Everyday is extraordinary for five doctors and...</td>
      <td>14</td>
      <td>177</td>
      <td>9.1</td>
      <td>12</td>
      <td>100</td>
      <td>43,574</td>
      <td>2021-06-17</td>
      <td>2021-09-16</td>
      <td>Thursday</td>
      <td>Jo Jung Suk, Jung Kyung Ho, Jeon Mi Do, Yoo Ye...</td>
      <td>91</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Flower of Evil</td>
      <td>Thriller, Romance, Crime, Melodrama</td>
      <td>Deception, Family Secret, Mystery, Suspense, S...</td>
      <td>Although Baek Hee Sung is hiding a dark secret...</td>
      <td>16</td>
      <td>31</td>
      <td>9.1</td>
      <td>16</td>
      <td>70</td>
      <td>94,811</td>
      <td>2020-07-29</td>
      <td>2020-09-23</td>
      <td>Wednesday, Thursday</td>
      <td>Lee Joon Gi, Jang Hee Jin, Moon Chae Won, Seo ...</td>
      <td>56</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Hospital Playlist</td>
      <td>Romance, Life, Drama, Medical</td>
      <td>Nice Male Lead, Multiple Mains, Slow Romance, ...</td>
      <td>The stories of people going through their days...</td>
      <td>17</td>
      <td>51</td>
      <td>9.1</td>
      <td>12</td>
      <td>90</td>
      <td>81,568</td>
      <td>2020-03-12</td>
      <td>2020-05-28</td>
      <td>Thursday</td>
      <td>Jo Jung Suk, Jung Kyung Ho, Jeon Mi Do, Yoo Ye...</td>
      <td>77</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Rank</th>
      <th>Popularity</th>
      <th>Score</th>
      <th>Episodes</th>
      <th>Duration</th>
      <th>Air_duration</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>100.000000</td>
      <td>100.000000</td>
      <td>100.000000</td>
      <td>100.000000</td>
      <td>100.00000</td>
      <td>100.000000</td>
      <td>100.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>50.500000</td>
      <td>179.480000</td>
      <td>319.730000</td>
      <td>8.770000</td>
      <td>18.08000</td>
      <td>66.540000</td>
      <td>53.860000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>29.011492</td>
      <td>106.655916</td>
      <td>367.437313</td>
      <td>0.159228</td>
      <td>12.24636</td>
      <td>13.105955</td>
      <td>35.920794</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>8.000000</td>
      <td>1.000000</td>
      <td>8.600000</td>
      <td>6.00000</td>
      <td>30.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>25.750000</td>
      <td>90.750000</td>
      <td>88.750000</td>
      <td>8.600000</td>
      <td>12.00000</td>
      <td>60.000000</td>
      <td>42.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>50.500000</td>
      <td>179.000000</td>
      <td>194.500000</td>
      <td>8.700000</td>
      <td>16.00000</td>
      <td>67.000000</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>75.250000</td>
      <td>262.250000</td>
      <td>397.500000</td>
      <td>8.900000</td>
      <td>20.00000</td>
      <td>75.000000</td>
      <td>64.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>100.000000</td>
      <td>368.000000</td>
      <td>2197.000000</td>
      <td>9.200000</td>
      <td>100.00000</td>
      <td>100.000000</td>
      <td>190.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig = plt.boxplot(df['Popularity'])
```


    
![png](output_16_0.png)
    


Popularity에 특히 더 인기 있는 몇 outlier 존재.


```python
fig = plt.boxplot(df['Score'])
```


    
![png](output_18_0.png)
    


Score는 사람이 임의로 매긴다는 특징에 걸맞게 outlier 없음.


```python
fig = plt.boxplot(df['Episodes'])
```


    
![png](output_20_0.png)
    


Episodes 에서는 특별히 더 많은 회차 수를 가진 드라마 몇 개 존재.


```python
fig = plt.boxplot(df['Duration'])
```


    
![png](output_22_0.png)
    


Duration, 한 회 당 길이를 대강 나타내는 수치인데 양쪽 다 outlier가 존재하나 단편 드라마도 몇 개 있을 것으로 보아 적은 길이의 outlier가 조금 더 많다.


```python
fig = plt.boxplot(df['Air_duration'])
```


    
![png](output_24_0.png)
    


방영 기간은 양쪽 다 outlier 존재하나 특히 더 길게 방영한 드라마가 꽤 있다.


```python
nums = df[['Rank', 'Popularity', 'Score', 'Episodes', 'Duration', 'Air_duration']]
fig = sns.pairplot(nums)
plt.show()
```


    
![png](output_26_0.png)
    


꽤 당연하게 방영 기간과 방영 회수가, 그리고 Rank와 Score가 꽤 상관관계가 있어보이고, 그 외의 관계는 눈에 띄게 선형적인 관계를 보이는 그래프는 없다. 


```python
fig = sns.heatmap(nums.corr(), annot=True, cmap = "viridis")
plt.show()
```


    
![png](output_28_0.png)
    


Genre 열에 어떤 값들이 있는 지 살펴보기:


```python
sp = df.Genre.str.split(', ')
```


```python
def flat(lis):
    flatList = []
    # Iterate with outer list
    for element in lis:
        if type(element) is list:
            # Check if type is list than iterate through the sublist
            for item in element:
                flatList.append(item)
        else:
            flatList.append(element)
    return flatList
```


```python
allsp = flat(sp)
df_genre = pd.DataFrame(allsp)
df_genre.value_counts()
```




    Drama            63
    Romance          45
    Thriller         33
    Mystery          31
    Comedy           28
    Life             22
    Action           21
    Melodrama        17
    Fantasy          15
    Historical       15
    Crime            12
    Political        11
    Law              11
    Psychological    11
    Supernatural      8
    Medical           7
    Horror            6
    Sci-Fi            5
    Youth             4
    Military          3
    Business          3
    Sports            3
    Food              1
    dtype: int64



Day_aired column에서 어떤 방영 요일이 많았는 지 보기


```python
df.Day_aired.value_counts()

```




    Saturday, Sunday            26
    Monday, Tuesday             21
    Friday, Saturday            20
    Wednesday, Thursday         16
    Friday                      13
    Thursday                     2
    Sunday, Saturday             1
    Friday, Saturday, Sunday     1
    Name: Day_aired, dtype: int64




```python
day = df['Day_aired'].str.split(', ')
allday = flat(day)
df_day = pd.DataFrame(allday)
df_day.value_counts()
```




    Saturday     48
    Friday       34
    Sunday       28
    Monday       21
    Tuesday      21
    Thursday     18
    Wednesday    16
    dtype: int64


